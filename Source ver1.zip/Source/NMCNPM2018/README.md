# NMCNPM2018
Nhóm 7 NM CNPM 2018
Đồ án môn học môn Nhập Môn Công Nghệ Phần Mềm 2018 của nhóm 7. GV: Nguyễn Thị Minh Tuyền


Member:
1. Trần Minh Cường
2. Tô Đồng Lưu
3. Nguyễn Nhật Dinh
4. Lưu Nhất Hàn
5. Châu Văn Nhật
